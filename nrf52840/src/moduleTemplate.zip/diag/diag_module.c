/*
 * Copyright (c) 2021 Nordic Semiconductor ASA
 *
 * SPDX-License-Identifier: LicenseRef-Nordic-5-Clause
 */

#include <event_manager.h>
#include <zephyr.h>

#define MODULE diag_module

#include "../app/app_module_event.h"
#include "../button/button_module_event.h"
#include "../data_bridge/data_bridge_event.h"
#include "../gps/gps_module_event.h"
#include "../mqtt/mqtt_module_event.h"
#include "../sensors/sensor_module_event.h"
#include "../diag/diag_module_event.h"
#include "../modules_common.h"

#include <memfault/core/trace_event.h>

#include <logging/log.h>

LOG_MODULE_REGISTER(diag_module, CONFIG_DIAG_MODULE_LOG_LEVEL);

struct diag_msg_data
{
    union
    {
        struct app_module_event app;
        struct button_module_event button;
        struct data_bridge_module_event data_bridge;
        struct diag_module_event diag;
        struct gps_module_event gps;
        struct mqtt_module_event mqtt;
        struct sensor_module_event sensor;
    } module;
};

/* Diag module message queue. */
#define DIAG_QUEUE_ENTRY_COUNT 10
#define DIAG_QUEUE_BYTE_ALIGNMENT 4

K_MSGQ_DEFINE(
    msgq_diag, sizeof(struct diag_msg_data), DIAG_QUEUE_ENTRY_COUNT, DIAG_QUEUE_BYTE_ALIGNMENT);

static struct module_data self = {
    .name = "diag",
    .msg_q = &msgq_diag,
};
static enum state_type {
	STATE_INIT
} state;

static char * state2str(enum state_type new_state)
{
    switch (new_state)
    {
        case STATE_INIT:
            return "STATE_INIT";
        default:
            return "Unknown";
    }
}

DECLARE_SET_STATE()

static bool event_handler(const struct event_header * eh)
{
    struct diag_msg_data msg = {0};
    bool enqueue_msg = false;

    TRANSLATE_EVENT_TO_MSG(app)
    TRANSLATE_EVENT_TO_MSG(button)
    TRANSLATE_EVENT_TO_MSG(data_bridge)
    TRANSLATE_EVENT_TO_MSG(diag)
    TRANSLATE_EVENT_TO_MSG(gps)
    TRANSLATE_EVENT_TO_MSG(mqtt)
    TRANSLATE_EVENT_TO_MSG(sensor)

    ENQUEUE_MSG(diag, DIAG)

    return false;
}

static void on_all_states(struct diag_msg_data * msg)
{
    if (IS_EVENT(msg, app, APP_EVT_LTE_CONNECTED))
    {
    }
}



static void module_thread_fn(void)
{
    struct diag_msg_data msg;

    self.thread_id = k_current_get();

    module_start(&self);
    state_set(STATE_INIT);


    while (true)
    {
        module_get_next_msg(&self, &msg);

        switch (state)
        {
            case STATE_INIT:
                break;
            default:
                LOG_WRN("Unknown diaglication state");
                MEMFAULT_TRACE_EVENT(Diag_UnknownAppState);
                break;
        }

        on_all_states(&msg);
    }
}


K_THREAD_DEFINE(diag_module_thread, CONFIG_DIAG_THREAD_STACK_SIZE, module_thread_fn, NULL, NULL, NULL,
    K_LOWEST_APPLICATION_THREAD_PRIO, 0, 0);

EVENT_LISTENER(MODULE, event_handler);
EVENT_SUBSCRIBE(MODULE, app_module_event);
EVENT_SUBSCRIBE(MODULE, button_module_event);
EVENT_SUBSCRIBE(MODULE, data_bridge_module_event);
EVENT_SUBSCRIBE(MODULE, diag_module_event);
EVENT_SUBSCRIBE(MODULE, gps_module_event);
EVENT_SUBSCRIBE(MODULE, mqtt_module_event);
EVENT_SUBSCRIBE(MODULE, sensor_module_event);




